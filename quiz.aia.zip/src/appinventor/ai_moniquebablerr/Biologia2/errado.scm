#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"errado","$Type":"Form","$Version":"31","ActionBar":"True","AlignHorizontal":"3","AlignVertical":"2","AppName":"Biologia","BackgroundImage":"errado.jpg","Title":"errado","TitleVisible":"False","Uuid":"0","$Components":[{"$Name":"Button1","$Type":"Button","$Version":"7","BackgroundColor":"&HFFFF0000","Shape":"2","Text":"Proxima","TextColor":"&HFFFFFFFF","Uuid":"-1607921644"}]}}
|#