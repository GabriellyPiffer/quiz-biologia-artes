#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"certo","$Type":"Form","$Version":"31","ActionBar":"True","AlignHorizontal":"3","AlignVertical":"2","AppName":"Biologia","BackgroundImage":"certo.jpg","Title":"certo","TitleVisible":"False","Uuid":"0","$Components":[{"$Name":"Button1","$Type":"Button","$Version":"7","BackgroundColor":"&HFF63B006","Text":"Proximo","TextColor":"&HFFFFFFFF","Uuid":"-281383003"}]}}
|#