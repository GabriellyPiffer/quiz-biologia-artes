#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","ActionBar":"True","AlignHorizontal":"3","AlignVertical":"2","AppName":"Biologia","BackgroundColor":"&HFFDBDAFF","BackgroundImage":"biologia.png","Title":"Screen1","TitleVisible":"False","Uuid":"0","$Components":[{"$Name":"Bot\u00e3o1","$Type":"Button","$Version":"7","BackgroundColor":"&HFF9D9DF4","FontBold":"True","Width":"-1065","Text":"Inicial","TextColor":"&HFF000000","Uuid":"-1800177659"}]}}
|#